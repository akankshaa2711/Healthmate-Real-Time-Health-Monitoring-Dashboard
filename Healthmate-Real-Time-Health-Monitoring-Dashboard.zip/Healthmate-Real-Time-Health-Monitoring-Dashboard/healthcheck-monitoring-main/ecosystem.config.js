module.exports = {
    apps : [{
      name   : "healthcheck-server",
      script : "./server.js",
      args   : "limit"
    }]
  }
