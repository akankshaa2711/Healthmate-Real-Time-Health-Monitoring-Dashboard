# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### 0.1.2 (2023-06-01)


### Features

* update packages ([f8ebfff](https://github.com/jayantapaul-18/healthcheck-monitoring/commit/f8ebfff761ef23bac076c4974d9011c3cc80f53f))
