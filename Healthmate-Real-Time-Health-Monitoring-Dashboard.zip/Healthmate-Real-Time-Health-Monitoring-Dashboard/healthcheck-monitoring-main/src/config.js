module.exports = {
  TIMEOUT: 5000,
  REQUEST_INTERVAL: 4000,
};
